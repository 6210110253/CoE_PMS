<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div>
         <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-200">
             <div class="container mx-auto px-6 py-8">
                

                <br>
                <div class="w-full p-4  bg-white border border-gray-200 rounded-lg shadow sm:p-8 dark:bg-gray-800 dark:border-gray-700">
                   
                    <?php $__currentLoopData = $meeting_resevations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meeting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($meeting->meeting->status == 'publish'): ?>
                        <div class="w-full  bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
    
                            <div class="px-5 pb-5">
                                <br>
                                <a >
                                    <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white"><?php echo e($meeting->meeting->title); ?></h5>
                                    <p class="font-normal text-gray-700 dark:text-gray-400">รายละเอียด <?php echo e($meeting->meeting->detail); ?></p>
                                    <p class="font-normal text-gray-700 dark:text-gray-400">ช่วงเวลาที่เข้าพบ <span><?php echo e($meeting->meeting->start_date); ?> - <?php echo e($meeting->meeting->end_date); ?> </span></p>
                                    <p class="font-normal text-gray-700 dark:text-gray-400">ชื่อผู้เข้าพบ <?php echo e($meeting->meeting->student->name); ?></p>
                                    
                                </a>
                                
                                <div class="flex justify-center gap-4">
                                    <div>
                                        <span class="text-3xl font-bold text-gray-900 dark:text-white"></span>
                                        <a href="#" class="accept text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800" data-id="<?php echo e($meeting->id); ?>">Approve</a>
                                    </div>
                                    <div>
                                        <span class="text-3xl font-bold text-gray-900 dark:text-white"></span>
                                        <a href="#" class="reject text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800" data-id="<?php echo e($meeting->id); ?>" >Reject</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <br>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                
 
             </div>
         </main>
     </div>
 </div>
 <script>
     $('.accept').click(function(){

    Swal.fire({

        text: "Are you sure you approve this project?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes'
        }).then((result) => {
            let id = $(this).attr('data-id');
                if (result.isConfirmed) {
                    $.ajax({
                        url: "<?php echo e(route('teacher.meeting.status')); ?>",
                        type: "POST",
                        data: {
                            _token : $('meta[name="csrf-token"]').attr('content'),
                            status : 'approve',
                            id : id
                        },
                        success: function(result){
                            if(result.status)
                            {
                                Swal.fire('Approved!', '', 'success').then((result)=>{
                                    location.reload();
                                })
                            }else{
                                Swal.fire(result.massege, '', 'error')
                            }
                        }

                    });
                }
        })
    })


    $('.reject').click(function(){

        Swal.fire({
            title: 'Enter your comment',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes',
            input: 'text',
            customClass: {
                validationMessage: 'my-validation-message'
            },
            preConfirm: (value) => {
                if (!value) {
                Swal.showValidationMessage(
                    '<i class="fa fa-info-circle"></i> Your name is required'
                )
                }
            }
            }).then((result) => {
                let id = $(this).attr('data-id');
                console.log(result.value);
                    if (result.isConfirmed) {
                        $.ajax({
                            url: "<?php echo e(route('teacher.meeting.status')); ?>",
                            type: "POST",
                            data: {
                                _token : $('meta[name="csrf-token"]').attr('content'),
                                status : 'reject',
                                comment : result.value,
                                id : id
                            },
                            success: function(result){
                                let id = $(this).attr('data-id');
                                if(result.status)
                                {
                                    Swal.fire('Rejected!', '', 'success').then((result)=>{
                                        location.reload();
                                    })

                                }else{
                                    Swal.fire(result.massege, '', 'error')
                                }
                            }

                        });
                    }
            })
    })
 </script>
  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
 <?php /**PATH C:\laragon\www\coe-pms\resources\views/pages/teacher/meeting/meeting.blade.php ENDPATH**/ ?>